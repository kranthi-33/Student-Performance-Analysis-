# Student-performance-analysis-using-Big-data
execution of this project is a piece of cake.
first of all save datasets.csv file and student.py in same folder.
then open terminal from same folder and type "python student.py".
Kudos.
